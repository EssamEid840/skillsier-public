package eventhandler

import (
	"context"
	"encoding/json"
	"fmt"
	"log"

	"github.com/IBM/sarama"
	"users-be/internal/application/user"
)

// KeycloakEvent represents the structure of events from Keycloak
type KeycloakEvent struct {
	Event     string                 `json:"event"`
	User      string                 `json:"user"`
	Email     string                 `json:"email"`
	Sub       string                 `json:"sub"`       // Keycloak user ID
	Name      string                 `json:"name"`
	Timestamp string                 `json:"timestamp"`
	Source    string                 `json:"source"`
	Details   map[string]interface{} `json:"details,omitempty"`
}

// KeycloakEventHandler handles events from Keycloak
type KeycloakEventHandler struct {
	userService *user.Service
}

// NewKeycloakEventHandler creates a new Keycloak event handler
func NewKeycloakEventHandler(userService *user.Service) *KeycloakEventHandler {
	return &KeycloakEventHandler{
		userService: userService,
	}
}

// HandleMessage processes a Kafka message containing a Keycloak event
func (h *KeycloakEventHandler) HandleMessage(ctx context.Context, message *sarama.ConsumerMessage) error {
	log.Printf("Received Keycloak event from topic=%s partition=%d offset=%d",
		message.Topic, message.Partition, message.Offset)

	// Parse the message
	var event KeycloakEvent
	if err := json.Unmarshal(message.Value, &event); err != nil {
		return fmt.Errorf("failed to unmarshal Keycloak event: %w", err)
	}

	log.Printf("Processing Keycloak event: type=%s user=%s email=%s sub=%s",
		event.Event, event.User, event.Email, event.Sub)

	// Route to appropriate handler based on event type
	switch event.Event {
	case "user_login", "LOGIN":
		return h.handleUserLogin(ctx, &event)
	case "user_register", "REGISTER":
		return h.handleUserRegister(ctx, &event)
	case "user_update", "UPDATE_PROFILE":
		return h.handleUserUpdate(ctx, &event)
	default:
		// Log unknown events but don't fail
		log.Printf("Unknown Keycloak event type: %s", event.Event)
		return nil
	}
}

// handleUserRegister creates a new user when they register in Keycloak
func (h *KeycloakEventHandler) handleUserRegister(ctx context.Context, event *KeycloakEvent) error {
	log.Printf("Handling user registration for: %s (sub: %s)", event.User, event.Sub)

	// Check if user already exists
	existingUser, err := h.userService.GetUserByKeycloakID(ctx, event.Sub)
	if err == nil && existingUser != nil {
		log.Printf("User %s already exists, skipping creation", event.Sub)
		return nil
	}

	// Parse name into first and last name
	firstName, lastName := parseName(event.Name)

	// Create user DTO
	dto := &user.CreateUserDTO{
		KeycloakID:    event.Sub,
		Username:      event.User,
		Email:         event.Email,
		FirstName:     firstName,
		LastName:      lastName,
		EmailVerified: false, // Will be updated when Keycloak verifies email
	}

	// Create user in database
	createdUser, err := h.userService.CreateUser(ctx, dto)
	if err != nil {
		return fmt.Errorf("failed to create user from Keycloak event: %w", err)
	}

	log.Printf("Successfully created user: id=%s username=%s email=%s",
		createdUser.ID, createdUser.Username, createdUser.Email)

	return nil
}

// handleUserLogin can be used to track user login events
// For now, we just log it, but you could update last_login timestamp, etc.
func (h *KeycloakEventHandler) handleUserLogin(ctx context.Context, event *KeycloakEvent) error {
	log.Printf("User login event: user=%s sub=%s", event.User, event.Sub)
	
	// Check if user exists, if not, create them
	// This handles the case where a user was created in Keycloak but the registration event was missed
	existingUser, err := h.userService.GetUserByKeycloakID(ctx, event.Sub)
	if err != nil || existingUser == nil {
		log.Printf("User %s not found, creating from login event", event.Sub)
		return h.handleUserRegister(ctx, event)
	}

	// User exists, you could update last_login timestamp here
	// For now, just log
	log.Printf("User %s (ID: %s) logged in", event.User, existingUser.ID)
	
	return nil
}

// handleUserUpdate handles user profile updates from Keycloak
func (h *KeycloakEventHandler) handleUserUpdate(ctx context.Context, event *KeycloakEvent) error {
	log.Printf("Handling user update for: %s (sub: %s)", event.User, event.Sub)

	// Get existing user
	existingUser, err := h.userService.GetUserByKeycloakID(ctx, event.Sub)
	if err != nil {
		// User doesn't exist, create them
		log.Printf("User %s not found, creating from update event", event.Sub)
		return h.handleUserRegister(ctx, event)
	}

	// Parse name
	firstName, lastName := parseName(event.Name)

	// Create update DTO
	// Only update fields that might have changed in Keycloak
	dto := &user.UpdateUserDTO{}
	
	if firstName != "" && firstName != existingUser.FirstName {
		dto.FirstName = &firstName
	}
	if lastName != "" && lastName != existingUser.LastName {
		dto.LastName = &lastName
	}

	// Only update if there are actual changes
	if dto.FirstName != nil || dto.LastName != nil {
		_, err := h.userService.UpdateUser(ctx, existingUser.ID, dto)
		if err != nil {
			return fmt.Errorf("failed to update user from Keycloak event: %w", err)
		}
		log.Printf("Successfully updated user: id=%s", existingUser.ID)
	} else {
		log.Printf("No changes detected for user: id=%s", existingUser.ID)
	}

	return nil
}

// parseName splits a full name into first and last name
// This is a simple implementation - you might want to make it more sophisticated
func parseName(fullName string) (firstName, lastName string) {
	if fullName == "" {
		return "", ""
	}

	// Simple split on first space
	parts := splitName(fullName)
	if len(parts) == 0 {
		return "", ""
	}
	if len(parts) == 1 {
		return parts[0], ""
	}
	
	// First part is first name, rest is last name
	firstName = parts[0]
	lastName = joinName(parts[1:])
	
	return firstName, lastName
}

// splitName splits a name by spaces
func splitName(name string) []string {
	var parts []string
	current := ""
	
	for _, char := range name {
		if char == ' ' {
			if current != "" {
				parts = append(parts, current)
				current = ""
			}
		} else {
			current += string(char)
		}
	}
	
	if current != "" {
		parts = append(parts, current)
	}
	
	return parts
}

// joinName joins name parts with spaces
func joinName(parts []string) string {
	result := ""
	for i, part := range parts {
		if i > 0 {
			result += " "
		}
		result += part
	}
	return result
}