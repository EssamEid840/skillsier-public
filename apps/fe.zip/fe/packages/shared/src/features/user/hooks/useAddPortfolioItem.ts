import { useMutation, useQueryClient } from '@tanstack/react-query';
import { userApi } from '../api/userApi';
import { queryKeys } from '../../../lib/api/queryClient';
import type { AddPortfolioItemRequest, PortfolioItem } from '@skillsier/types';

export function useAddPortfolioItem() {
  const queryClient = useQueryClient();

  return useMutation<PortfolioItem, Error, AddPortfolioItemRequest>({
    mutationFn: userApi.addPortfolioItem,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.users.portfolio });
      queryClient.invalidateQueries({ queryKey: queryKeys.users.freelancerProfile });
    },
  });
}