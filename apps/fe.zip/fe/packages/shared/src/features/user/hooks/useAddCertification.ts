import { useMutation, useQueryClient } from '@tanstack/react-query';
import { userApi } from '../api/userApi';
import { queryKeys } from '../../../lib/api/queryClient';
import type { AddCertificationRequest, Certification } from '@skillsier/types';

export function useAddCertification() {
  const queryClient = useQueryClient();

  return useMutation<Certification, Error, AddCertificationRequest>({
    mutationFn: userApi.addCertification,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.users.certifications });
      queryClient.invalidateQueries({ queryKey: queryKeys.users.freelancerProfile });
    },
  });
}