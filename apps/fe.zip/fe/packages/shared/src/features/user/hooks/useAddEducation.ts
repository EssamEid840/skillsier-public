import { useMutation, useQueryClient } from '@tanstack/react-query';
import { userApi } from '../api/userApi';
import { queryKeys } from '../../../lib/api/queryClient';
import type { AddEducationRequest, Education } from '@skillsier/types';

export function useAddEducation() {
  const queryClient = useQueryClient();

  return useMutation<Education, Error, AddEducationRequest>({
    mutationFn: userApi.addEducation,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.users.education });
      queryClient.invalidateQueries({ queryKey: queryKeys.users.freelancerProfile });
    },
  });
}