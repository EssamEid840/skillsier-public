import { useMutation, useQueryClient } from '@tanstack/react-query';
import { userApi } from '../api/userApi';
import { queryKeys } from '../../../lib/api/queryClient';
import type { AddSkillRequest, FreelancerSkill } from '@skillsier/types';

export function useAddSkill() {
  const queryClient = useQueryClient();

  return useMutation<FreelancerSkill, Error, AddSkillRequest>({
    mutationFn: userApi.addSkill,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.users.skills });
      queryClient.invalidateQueries({ queryKey: queryKeys.users.freelancerProfile });
    },
  });
}